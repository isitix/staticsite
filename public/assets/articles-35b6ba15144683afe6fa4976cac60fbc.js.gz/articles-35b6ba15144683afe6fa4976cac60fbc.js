/**
 * Created by mdautrey on 07/04/16.
 */

$("#contactbutton").click(function() {
    $("#contactform").toggle();
});
