(function() {
  Jquery(function() {
    return $("#contactbutton").click(function() {
      return $("#contactform").toggle();
    });
  });

}).call(this);
